var students=[
    {
        name:"Waqib",
        age:23,
        group:"A",
        country:"Bangladesh"
    },
    {
        name:"Rafeen",
        age:24,
        group:"B",
        country:"India"
    },
    {
        name:"James",
        age:25,
        group:"C",
        country:"UK"
    },
    {
        name:"Ismail",
        age:21,
        group:"D",
        country:"KSA"
    },
    {
        name:"Umair",
        age:22,
        group:"D",
        country:"Pakistan"
    },


];
for(var i=0;i<students.length;i++){
    console.log(students[i].name);
    console.log(students[i].country);


}
students.forEach(

    function(features,index)
    {
        console.log(features,index);

    }
)
