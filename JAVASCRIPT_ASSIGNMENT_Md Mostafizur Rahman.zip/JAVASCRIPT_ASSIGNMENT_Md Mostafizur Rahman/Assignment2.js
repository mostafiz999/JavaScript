console.log("Program to print table of 5:");
let tableOfFive=[5,10,15,20,25,30];
console.log(tableOfFive);
for(let i=0;i<tableOfFive.length;i++)
{
    console.log("Here is the number that divisible by 5:",tableOfFive[i])
}
console.log("Creating 5 variables for holding marks of 5 subjects:");
let c=67;
let cPlus=78;
let java=89;
let python=98;
let webDev=94;
//let mark="";
//for C:
if(c<60){
    console.log("Your grade in C is: Fail");
}
else if(c>=60 && c<70){
    console.log("Your grade in C is: D");

}
else if(c>=70 && c<80){
    console.log("Your grade in C is: C");

}
else if(c>=80 && c<90){
    console.log("Your grade in C is: B");

}
else if(c>=90 && c<95){
    console.log("Your grade in C is: A");

}
else if(c>=95 && c<=100){
    console.log("Your grade in C is: A++");

}

//FOR C++

if(cPlus<60){
    console.log("Your grade in C++ is: Fail");
}
else if(cPlus>=60 && cPlus<70){
    console.log("Your grade in C++ is: D");

}
else if(cPlus>=70 && cPlus<80){
    console.log("Your grade in C++ is: C");

}
else if(cPlus>=80 && cPlus<90){
    console.log("Your grade in C++ is: B");

}
else if(cPlus>=90 && cPlus<95){
    console.log("Your grade in C++ is: A");

}
else if(cPlus>=95 && cPlus<=100){
    console.log("Your grade in C++ is: A++");

}
//FOR JAVA
if(java<60){
    console.log("Your grade in JAVA is: Fail");
}
else if(java>=60 && java<70){
    console.log("Your grade in JAVA is: D");

}
else if(java>=70 && java<80){
    console.log("Your grade in JAVA is: C");

}
else if(java>=80 && java<90){
    console.log("Your grade in JAVA is: B");

}
else if(java>=90 && java<95){
    console.log("Your grade in JAVA is: A");

}
else if(java>=95 && java<=100){
    console.log("Your grade in JAVA is: A++");

}

//FOR PYTHON
if(python<60){
    console.log("Your grade in PYTHON is: Fail");
}
else if(python>=60 && python<70){
    console.log("Your grade in PYTHON is: D");

}
else if(python>=70 && python<80){
    console.log("Your grade in PYTHON is: C");

}
else if(python>=80 && python<90){
    console.log("Your grade in PYTHON is: B");

}
else if(python>=90 && python<95){
    console.log("Your grade in PYTHON is: A");

}
else if(python>=95 && python<=100){
    console.log("Your grade in PYTHON is: A++");

}
//for WBDEV.
if(webDev<60){
    console.log("Your grade in WBD  is: Fail");
}
else if(webDev>=60 && webDev<70){
    console.log("Your grade in WBD  is: D");

}
else if(webDev>=70 && webDev<80){
    console.log("Your grade in WBD  is: C");

}
else if(webDev>=80 && webDev<90){
    console.log("Your grade in WBD is: B");

}
else if(webDev>=90 && webDev<95){
    console.log("Your grade in WBD  is: A");

}
else if(webDev>=95 && webDev<=100){
    console.log("Your grade in WBD is: A++");

}
console.log("There are simple method to do that but i did like this because you give a condition to declare five variables to solve the problem.");